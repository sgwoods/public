;; load.lsp

(load "/cc/users/woods/ideas/csp/bm")
(load "/cc/users/woods/ideas/csp/bt")
(load "/cc/users/woods/ideas/csp/ct")

(load "/cc/users/woods/ideas/csp/utility")
(load "/cc/users/woods/ideas/csp/compile")

;; load Queens domain
(load "queens")   

;; load MPR domain
(load "mpr-simple")   ;; functionality
(load "mpr-setup")    ;; template, situation information


