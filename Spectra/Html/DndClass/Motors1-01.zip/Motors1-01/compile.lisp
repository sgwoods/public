;; compile.lsp

(defun compile-all (&optional (speed 'fast))
"
Compile CSP application
"
  (if (eq speed 'fast)
      (proclaim '(optimize (compilation-speed 0)))
    (if (eq speed 'slow)
	(proclaim '(optimize (compilation-speed 3)))
      (proclaim '(optimize (compilation-speed 3))))) 

  (compile-file "/cc/users/woods/ideas/csp/bt")
  (compile-file "/cc/users/woods/ideas/csp/bm")
  (compile-file "/cc/users/woods/ideas/csp/ct")

  (compile-file "/cc/users/woods/ideas/csp/utility")

  (compile-file "/cc/users/woods/ideas/csp/mpr-simple")
  (compile-file "/cc/users/woods/ideas/csp/mpr-setup")
  (compile-file "/cc/users/woods/ideas/csp/queens")

  (load "load")
)


