/*  This code generated from file Sit-q-i1-dist1-default-25 automatically */

int main() {
                             /* define all "first" variables at head */
int   firstInt;
char  firstChar;
float firstReal;
int   firstBoolean;

int   firstArrayI[20];          
char  firstArrayC[15];
float firstArrayReal[50];
int   firstArrayBoolean[35];

                            /* translate code */
firstint = firstint;                 
char A[99];

int var-name950;
firstint = var-name950;     /* implied definition required - same type as firstint */

firstBoolean = !(firstint == var-name956);  /* implied def'n and initializ required */
}


