
(defun t4 () (load 
 	     "Macintosh HD:Languages:Allegro Common Lisp:qcsp:test4.lisp"))

(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:comment")
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:compile-ao")

(comment1 "Loading hierarchy ..." nil)
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:hierarchy")

(comment1 "Loading ao-revise-fns ..." nil)
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:ao-revise-fns")

(comment1 "Loading ao-revise-aggressive ..." nil)
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:ao-revise-aggressive")

(comment1 "Loading applyr ..." nil)
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:applyr")

(comment1 "Loading example-extend ..." nil)
(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:example-extend")
;;(load "Macintosh HD:Languages:Allegro Common Lisp:qcsp:example-simple")

(defun testao1 ()
  (setq AO1 (ao-revise v1 v2 rfn 2)))

(defun testao2 ()
  (setq AO2 (ao-revise v0 v1 rfn 2)))

(defun testao3 ()
  (setq AO3 (ao-revise v2 v0 rfn 2)))



   